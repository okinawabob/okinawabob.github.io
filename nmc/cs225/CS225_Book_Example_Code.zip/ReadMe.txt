These files contain all of the code listings in

       C++: A Beginner's Guide, 2nd Edition

The source code is organized into files by module.
Within each module file, the listings are stored
in the same order as they appear in the book.
For example, the source code for the programs
in Module 4 are in the file Module4.lst.
Simply edit the appropriate file to extract the
listing in which you are interested.

For your convenience, the source code for each project
has also been organized by module and stored in its
own directory.  For example, the projects for Module 3
are in the directory Projects\Module3.
