#include <iostream>
using namespace std;
int main()
{
  int nScore=0, nTotal=0, nCntr=0;
  while(nScore >= 0)
  {
    cout << "\nEnter Score\n>";
    cin >> nScore;
    if(nScore >= 0)
    {
      nTotal = nTotal + nScore;
      cout << "Score " << ++nCntr 
           << " = " << nScore << endl;
    }
  }
  cout << "----------------------"
       << "\nThe Average Score = " 
       << nTotal/nCntr << endl;
	return 0;
}
