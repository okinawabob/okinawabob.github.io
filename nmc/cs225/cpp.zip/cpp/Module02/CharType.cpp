/********************************************
* PROGRAM: CharType.cpp
********************************************/
#include <iostream>
using namespace std;
int main()
{
  char  cGrade = 'A', cScore = 67;
  int   nSize;
  nSize = sizeof(cGrade);
  cout  << "Attendance Grade = " << cGrade
        << endl
        << "Attendance Score = " << cScore
        << endl
        << "Size of cGrade = " << nSize << endl;
  cout  << "Enter a Grade: ";
  cin   >> cGrade;
  cout  << "You entered " << cGrade << endl;
  system("pause");
  return 0;
}

