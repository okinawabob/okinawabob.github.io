/********************************************
* PROGRAM: BoolType.cpp
********************************************/
#include <iostream>
#include <string>
using namespace std;
int main()
{
  bool bWorkDay = true, bRainDay = false, bGo2Work;
  bGo2Work = bWorkDay && !bRainDay;
  cout  << "Work day = " << bWorkDay << endl
        << "Rain day = " << bRainDay << endl
        << "-----------------------" << endl
        << "Go work  = " << bGo2Work << endl << endl;
  bRainDay = true,
  bGo2Work = bWorkDay && !bRainDay;
  cout  << "Work day = " << bWorkDay << endl
        << "Rain day = " << bRainDay << endl
        << "-----------------------" << endl
        << "Go work  = " << bGo2Work << endl << endl;
  system("pause");
  return 0;
}

