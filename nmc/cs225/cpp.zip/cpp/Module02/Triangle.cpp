/********************************************
* PROGRAM: Triangle.cpp   			       	*
* Area and Perimeter of a Trangle  			*
********************************************/
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
    float fBase, fHeight;
    float fArea, fPerimeter, fHypot;

    cout << "This program calculates "
         << "the area and perimeter of "
         <<  "a triangle" << endl;

    cout << "Enter Base:";
    cin >> fBase;
    cout << "Enter Height: ";
    cin >> fHeight;

    fArea = fBase * fHeight / 2;
    fHypot = sqrt(fBase*fBase + fHeight*fHeight);
    fPerimeter = fBase + fHeight + fHypot;

    cout << "Area = " <<  fArea
         << "     Perimeter = "
         << fPerimeter << endl;

	system("pause");
    return 0;
}

