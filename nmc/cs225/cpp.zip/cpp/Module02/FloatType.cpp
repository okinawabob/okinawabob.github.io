/********************************************
* PROGRAM: FloatType.cpp
********************************************/
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
  float  fA=127, fB;
  double dA=127, dB;
  long  double  ldA=127, ldB;

  fB = sqrt(fA);
  dB = sqrt(dA);
  ldB = sqrtl(ldA);
  cout  << setprecision(20)
        << " fB = " << fB << "  fA=" << fB*fB << endl
        << " dB = " << dB << "  dA=" << dB*dB << endl
        << "ldB = " << ldB << " ldA=" << ldB*ldB << endl
        << "Size of float = " << sizeof(fA) << endl
        << "Size of double = " << sizeof(dA) << endl
        << "Size of long double = " << sizeof(ldA) << endl;
  system("pause");
  return 0;
}

