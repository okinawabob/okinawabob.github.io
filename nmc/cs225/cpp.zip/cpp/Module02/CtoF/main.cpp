/********************************************
* PROGRAM: CtoF.cpp
********************************************/
#include <iostream>
using namespace std;
int main()
{
	float	fDegC, fDegF;
	cout << "This program converts a temperature from\n"
        << "degrees Celsius to degrees Fahrenheit.\n\n";

	cout << "Enter the Celsius Temperature\n>     C\r>";
  cin >> fDegC;
  fDegF = 1.8 * fDegC + 32;
  cout << "\nResults: " << fDegC << "C = " 
        << fDegF << "F\n\n";
  // system("pause"); // Use statement for Use Phase only
  return 0;
}

