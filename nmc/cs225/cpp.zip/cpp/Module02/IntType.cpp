/********************************************
* PROGRAM: IntType.cpp
********************************************/
#include <iostream>
using namespace std;
int main()
{
  int         nWeight  = 50000;
  short int   snWeight = 50000;
  long  int   lnWeight = 50000;
  cout  << "Normal Weight = " <<   nWeight
        << endl
        << "Small Weight = "   <<  snWeight
        << endl
        << "Big Weight = "     <<  lnWeight
        << endl
        << "Size of int = "
        << sizeof(nWeight) << endl
        << "Size of short int = "
        << sizeof(snWeight) << endl
        << "Size of long int = "
        << sizeof(lnWeight) << endl;
  system("pause");
  return 0;
}

