#include <iostream>
using namespace std;
int main()
{
  int nCnt = 1;
  while(nCnt <= 5)
  {				
    cout << "In Loop " 
      << nCnt << endl;
    nCnt = nCnt + 1;
  }
  cout << "Done";
	return 0;
}
