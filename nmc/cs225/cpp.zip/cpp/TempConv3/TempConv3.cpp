#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  //  DECLARATION SECTION
  char cQuestion;
  float fTemperature;
  cout << fixed;   // Allows float point format

  //  PROCESSING SECTION
  cout << "This program converts temperatures between\n"
      << "degrees Celsius and degrees Fahrenheit.\n"
      << "You may enter either a Celsius or "
      << "Fahrenheit\ntemperature for conversion.\n\n";
  while(true)
  {
    cout << "> <-- Enter C (Celsius), F (Fahrenheit), or Q (Quit)\r>";
    cin >> cQuestion;
    cin.ignore(100,'\n');

    if(cQuestion == 'C' || cQuestion == 'c')
    {
      cout << "       <-- Enter temperature in degrees Celsius\r>";
      cin >> fTemperature;
      cin.ignore(100,'\n');
      cout << "Results: " << setprecision(2)
          << fTemperature << " C = "
          << (((fTemperature * 180) / 100) + 32) << " F\n";
    }
    else if(cQuestion == 'F' || cQuestion == 'f')
    {
      cout << "       <-- Enter temperature in degrees Fahrenheit  \r>";
      cin >> fTemperature;
      cin.ignore(100,'\n');
      cout << "Results: " << setprecision(2)
          << fTemperature << " F = "
          << (((fTemperature - 32) * 100) / 180) << " C\n";
    }
    else if (cQuestion == 'Q' || cQuestion == 'q')
    {
      cout << "\nGood bye";
      return 0;
    }
    else
    {
      cout << "\a";
    }
  }
}
