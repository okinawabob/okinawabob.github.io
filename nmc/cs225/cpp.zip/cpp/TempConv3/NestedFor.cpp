#include <iostream>
using namespace std;
int main(void)
{
  int nI, nJ;
  for(nI=1; nI<=5; nI++)
    cout << nI << " ";
  cout << endl;
  for(nI = 5; nI >= 0; --nI)
  {
    cout << endl;
    for( nJ = 4; nJ >= 0; --nJ)
    {
      cout << (nI + nJ) << ' ';
    }
  }
  return 0;
}
