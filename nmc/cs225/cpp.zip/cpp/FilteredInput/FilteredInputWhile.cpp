#include <iostream>
using namespace std;
int main( )
{
  char cEntry = 'f';
  while(cEntry != 'y' && cEntry != 'n')
  {
    cout << "Do you like Programming? (y or n)\n>";
    cin >> cEntry;
    cin.ignore(100,'\n');

    if(cEntry == 'y')
      cout << "I\'m glad you like programming!";
    else if(cEntry == 'n')
      cout << "You will like it if you study.";
    else
      cout << "You must enter either y or n!\n\n";
  }

  cout << "\n\nDone\n\n";
  return 0;
}
