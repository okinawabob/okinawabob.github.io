#include <iostream>
using namespace std;
int main()
{
    int nMax=0, nMin=100, nCnt=0, nSum=0, nScore;
    int nA=0, nB=0, nC=0, nD=0, nF=0;
    cout << "This program will calculate the maximum score,\n"
        << "minimum score, average score, and grade distribution\n"
        << "for a series of entered scores.\n\n";
    while(true)
    {
        cout << "                 (-1 to end)\rEnter score: ";
        cin >> nScore;
        if(nScore < 0)
        {
            cout << "RESULTS:\n----------------"
                << "\nAverage Score = " << nSum/nCnt
                << "\nMaximum Score = " << nMax
                << "\nMinimum Score = " << nMin
                << "\nA\'s = " << nA
                << "\nB\'s = " << nB
                << "\nC\'s = " << nC
                << "\nD\'s = " << nD
                << "\nF\'s = " << nF
                << "\n\nDone"
            return 0;
        }
        nCnt++;
        nSum = nSum + nScore;
    }
}
