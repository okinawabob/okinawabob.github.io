#include <iostream>
using namespace std;
int main()
{
    int nI, nMax=0, nMin=100, nCnt=0, nSum=0, nScore, nGrdCnt[5];
    char cGrade[] = {'F', 'D', 'C', 'B', 'A'};
    for(nI = 0; nI < 5; nI++)
        nGrdCnt[nI] = 0;
    cout << "This program will calculate the maximum score,\n"
        << "minimum score, average score, and grade distribution\n"
        << "for a series of entered scores.\n\n";
    while(true)
    {
        cout << "                 (-1 to end)\rEnter score: ";
        cin >> nScore;
        if(nScore < 0)break;
        nCnt++;
        nSum = nSum + nScore;
        if(nScore > nMax)nMax = nScore;
        if(nScore < nMin)nMin = nScore;
        if(nScore >= 90)nGrdCnt[4]++; 
        else if(nScore >= 80)nGrdCnt[3]++; 
        else if(nScore >= 70)nGrdCnt[2]++; 
        else if(nScore >= 60)nGrdCnt[1]++; 
        else nGrdCnt[0]++;   
    }
    cout << "RESULTS:\n----------------"
        << "\nMaximum Score = " << nMax
        << "\nMinimum Score = " << nMin
        << "\nAverage Score = " << nSum/nCnt;
    for(nI=4; nI>=0; nI--)
        cout << endl << cGrade[nI] <<"\'s = " << nGrdCnt[nI];
    cout << "\n\nDone";
    return 0;
}
