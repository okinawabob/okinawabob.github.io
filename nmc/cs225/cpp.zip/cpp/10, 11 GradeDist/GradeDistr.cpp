#include <iostream>
using namespace std;
int main()
{
    int nI, nScore, nGrdCnt[5];
    char cGrade[] = {'F', 'D', 'C', 'B', 'A'};
    for(nI = 0; nI < 5; nI++)
        nGrdCnt[nI] = 0;
    cout << "This program will calculate the grade \n"
        << "distribution for a series of entered scores.\n\n";
    while(true)
    {
        cout << "                 (-1 to end)\rEnter score: ";
        cin >> nScore;
        if(nScore < 0)break;
        if(nScore >= 90)nGrdCnt[4]++; 
        else if(nScore >= 80)nGrdCnt[3]++; 
        else if(nScore >= 70)nGrdCnt[2]++; 
        else if(nScore >= 60)nGrdCnt[1]++; 
        else nGrdCnt[0]++;   
    }
    cout << "\nRESULTS:\n----------------";
    for(nI=4; nI>=0; nI--)
        cout << endl << cGrade[nI] <<"\'s = " << nGrdCnt[nI];
    cout << "\n\nDone";
    return 0;
}
