#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	float fCost, fFee;
	cout << "Enter the cost of the building\n> $";
	cin >> fCost;
	if(fCost <= 5000)
		fFee = fCost * 0.08;
	else if(fCost <= 85000)
		fFee = 400+(fCost-5000)*0.03;
  else
		fFee = 400+(fCost-5000)*0.025;
	cout << fixed<< setprecision(2) 
       << "Your fee = $" << fFee <<endl;
  system("pause");
	return 0;
}
