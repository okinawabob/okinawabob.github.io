#include <iostream>
using namespace std;

int main()
{
  int nScore, nTotal=0, nCntr=0;
  while(nCntr < 5)
  {
    cout << "\nEnter Score\n>";
    cin >> nScore;
    nTotal = nTotal + nScore;
    nCntr = nCntr + 1;
    cout << "Score " << nCntr 
         << " = " << nScore << endl;
  }
  cout << "--------------------------"
       << "\nThe Average Score = " 
       << nTotal/5 << endl;
	return 0;
}
