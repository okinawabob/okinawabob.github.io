#include <iostream>
#include <iomanip>
using namespace std;
int main( )
{
  int   nA=12, nB=7;
  cout << "  $" << setw(5) << nA << endl;
  if(nA >= nB)
  {
    cout << "- $" << setw(5) << nB;
    cout << "\n-------------\n";
    cout << "  $" << setw(5) << nA - nB;
  }
  else
  {
    cout << "+ $" << setw(5) << nB;
    cout << "\n-------------\n";
    cout << "  $" << setw(5) << nA + nB;
  }
  cout << "\n\nDone\n\n";
  return 0;
}
