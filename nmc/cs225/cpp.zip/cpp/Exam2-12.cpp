#include <iostream>
using namespace std;

int main()
{
  int nEnter, nOut, nVal = 120;
  cin >> nEnter;
  if ((nVal > 100) && (nEnter >= 50))
      nOut = nVal + nEnter;
  else
      nOut = nVal - nEnter;
  cout << nVal<< ' ' << nEnter << ' ' << nOut;

  return 0;
}
