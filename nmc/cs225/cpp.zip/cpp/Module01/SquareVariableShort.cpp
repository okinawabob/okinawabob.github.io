/*********************************************
* PROGRAM: SquareVariableShort.cpp           *
* More compact version of previous program	*
*********************************************/
#include <iostream>
using namespace std;
int main()
{
	int nLength = 6;  // Declare and Intialize
	cout 	<< "A Square with Length = " << nLength
			<< " inches" <<endl;
	cout 	<< "has an Area = " << nLength * nLength
			<< " square inches" << endl;
	return 0;
}

