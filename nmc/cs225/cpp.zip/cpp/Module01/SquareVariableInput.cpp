/********************************************
* PROGRAM: SquareVariableInput.cpp          *
* More compact version of previous program  *
********************************************/
#include <iostream>
using namespace std;
int main()
{
    int nLength, nArea, nPerimeter;

    cout << "This program calculates "
         << "the area and perimeter of "
         <<  "a square" << endl;

    cout << "Enter Length: ";
    cin >> nLength;

    nArea = nLength * nLength;
    nPerimeter = nLength * 4;

    cout << "Area = " <<  nArea
         << "     Perimeter = "
         << nPerimeter << endl;

    return 0;
}

