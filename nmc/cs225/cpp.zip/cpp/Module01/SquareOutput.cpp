/*********************************************
* PROGRAM: SquareOutput.cpp                  *
*********************************************/
#include <iostream> 	// Output library functions
using namespace std;	// Required 1998 standard C++
int main()		// Start of program
{
	cout 	<< "A Square with Length = ";
	cout	<< 5 << endl;
	cout	<< "has an Area = 25" << endl << endl;
	return 0;		// End of program
}
