int main()		//Program start 
{				//Program body start	
	   //STATEMENTS GO HERE
	   return 0; 	//Program ends
}				//Program body end
