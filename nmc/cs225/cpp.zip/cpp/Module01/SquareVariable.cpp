/*********************************************
* PROGRAM: SquareVariable.cpp                *
*********************************************/
#include <iostream> 	// Library functions
using namespace std;	// Required Standard C++
int main()
{
	int nArea; 			// Variable declaration
	int nLength; 		// Variable declaration
	nLength = 5;		// Variable initialization
	nArea = nLength * nLength;
	cout 	<< "A Square with Length = ";
	cout	<< nLength << endl;
	cout	<< "has an Area = " << nArea;
	cout	<< endl << endl;
	return 0;
}

