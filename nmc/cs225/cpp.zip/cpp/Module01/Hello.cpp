#include <iostream>
using namespace std;
int main()		//Program start
{				//Program body start
	cout << "Hello World" << endl;
	return 0; 		//Program ends
}				//Program body end
