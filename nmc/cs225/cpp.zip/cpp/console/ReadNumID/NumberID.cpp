#include <iostream>
#include <cctype>
#include <cstdlib>
#include <conio.h>
using namespace std;
int main(void)
{
  unsigned int nI, nNumber;
  char cEntry, szDigits[7];
  cout << "Enter your identification number\n>";
  nI=0;
  do
  {
    cEntry = getch();
    if(cEntry == 0x0D)    // Enter key pressed?
      break;
    if(!isdigit(cEntry))  // Test if NOT digit
    {
      putch('\a');        // Ring bell
      continue;           // Try again
    }
    putch(cEntry);        // Display character
    szDigits[nI++] = cEntry;  // Assemble string
  }while(nI < sizeof(szDigits)-1);
  szDigits[nI] = '\0';
  nNumber = atoi(szDigits);
  cout << "\n\nString = " << szDigits << "  Number = " << nNumber;
  cout << endl;
  system("pause");
  return(0);
}
