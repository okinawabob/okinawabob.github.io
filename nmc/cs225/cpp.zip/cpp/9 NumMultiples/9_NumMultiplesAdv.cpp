#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
  int nIn, nCnt=0;
  cout << "Enter the number: ";
  cin >> nIn;
  while(nCnt < 10)
    cout << endl << setw(2) << ++nCnt << " x " 
        << setw(2) << nIn << " = " <<  setw(3) 
        <<nCnt * nIn; 
  return 0;
}
