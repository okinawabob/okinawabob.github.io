#include <iostream>
using namespace std;
int main()
{
  int nIn, nCnt=0;
  cout << "Enter the number: ";
  cin >> nIn;
  while(nCnt < 10)
    cout << endl << ++nCnt << " x " << nIn << " = " << nCnt * nIn; 
  return 0;
}
