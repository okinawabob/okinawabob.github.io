/******************************
*  Temperature Converter.cpp
*  by Robert Laurie
******************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main(void)
{
	//  DECLARATION SECTION
	char cQuestion;
	float fTemperature;
 	//  PROCESSING SECTION
	cout << "This program converts temperatures between\n"
		 << "degrees Celsius and degrees Fahrenheit.\n"
		 << "You may enter either a Celsius or "
		 << "Fahrenheit\ntemperature for conversion.\n\n";
	cout << "> <-- Enter C (Celsius) or F (Fahrenheit)\r>";
	cin >> cQuestion;
	cin.ignore(100,'\n');
	cout << fixed << showpoint << setprecision(2);
  if(cQuestion == 'C' || cQuestion == 'c')
	{
		cout << "      <-- Enter Celsius Temperature\r>";
		cin >> fTemperature;
		cin.ignore(100,'\n');
		cout << "Results: " << setprecision(2)
		     << fTemperature << " C = "
		     << (((fTemperature * 180) / 100) + 32) << " F\n";
	}
	else if(cQuestion == 'F' || cQuestion == 'f')
	{
		cout << "      <-- Enter Fahrenheit Temperature\r>";
		cin >> fTemperature;
		cin.ignore(100,'\n');
		cout << "Results: " << setw(6)
        << fTemperature << " F = " << setw(6)
        << (((fTemperature - 32) * 100) / 180) << " C\n";
	}
  else
    cout << "Enter either C or F\n";
  return 0;
}
