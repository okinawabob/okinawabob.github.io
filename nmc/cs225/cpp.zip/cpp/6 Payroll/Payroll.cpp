/**********************
*  Payroll.cpp
*  by Robert Laurie
**********************/
#include <iostream>
using namespace std;

int main()
{
  int nEmpNum, ;
  double dHoursWork, dPayRate, dGrossPay, dNetPay;
    
  cout << "This program caluculates payroll for an employee.\n\n";
  cout << "What is your employee number?\n>";
  cin >> nEmpNum;
  cout << "How many hours did you work?\n>";
  cin >> dHoursWork;
  cout << "What is your Pay Rate?\n>$";
  cin >> dPayRate;
  
  if(dHoursWork > 60)
    cout << "Error: Hours worked exceeded 60 hours!\n\n";
  else if(dPayRate > 30)
    cout << "Error: Pay Rated exceeded $30 per hour!\n\n";
  else 
  {
    if(dHoursWork > 40)
    {
      dGrossPay = (40*dPayRate) + (dHoursWork - 40)*dPayRate*1.5;
    }
    else
    {
      dGrossPay = dHoursWork * dPayRate;
    }
    dNetPay = dGrossPay - dGrossPay*0.1;
    cout << "\n\n------------------------------"
         << "\nEmployee Number: " << nEmpNum
         << "\n   Hours worked: " << dHoursWork
         << "\n       Pay Rate: $" << dPayRate << "/hour"
         << "\n      Gross Pay: $" << dGrossPay
         << "\n   Tax Withheld: $" << dGrossPay * 0.1
         << "\n        Net Pay: $" << dNetPay 
         << "\n\n------------------------------\n\n";
  }
  cout << "Done\n";
  return 0;
}
