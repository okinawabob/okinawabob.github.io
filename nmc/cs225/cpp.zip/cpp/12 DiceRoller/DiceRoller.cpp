#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
int main(void)
{
  int nI, nJ, nRoll, nDiceCount[13];
  for(nI = 2; nI <= 12; nI++) nDiceCount[nI] = 0;
  srand((unsigned) time(NULL));
  for(nI = 1; nI <= 1000000; nI++)
  {
    nRoll = (1+(rand()%6)) + (1+(rand()%6));
    nDiceCount[nRoll]++;
  }
  cout << "The distribution for one million rolls of two dice is:\n";
  for(nI = 12; nI >= 2; nI--)
  {
    cout << endl << setw(2) << nI << " = " << setw(6)
      << nDiceCount[nI] << "  |";
    for(nJ = nDiceCount[nI]/10000; nJ > 0; nJ--) cout << "=";
  }
  cout << endl;
  system("pause");
  return(0);
}
