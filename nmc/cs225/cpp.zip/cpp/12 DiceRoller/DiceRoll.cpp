#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
void bar_graph(int nCount, int nScale);
int main(void)
{
  int nI, nRoll, nDiceCount[13];
  for(nI = 2; nI <= 12; nI++) nDiceCount[nI] = 0;
  srand((unsigned) time(NULL));
  for(nI = 1; nI <= 1000000; nI++)
    {
        nRoll = (1+(rand()%6)) + (1+(rand()%6));
    nDiceCount[nRoll]++;
    }
  cout << "The distribution for 10,000 rolls of two dice is:\n";
  for(nI = 12; nI >= 2; nI--)
  {
    cout << endl << setw(2) << nI << " = " << setw(7)
      << nDiceCount[nI] << "  |";
    bar_graph(nDiceCount[nI], 10000);
  }
     cout << endl;
     return(0);
}

void bar_graph(int nCount, int nScale)
{
  int nI;
  for(nI = nCount/nScale; nI > 0; nI--) cout << "=";
}
